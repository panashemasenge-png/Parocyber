# Website Cloning Lab

## Objective
To understand how website cloning works and how attackers abuse this technique in phishing campaigns.

**What I assessed & how I ran it:**

So to kick of my social engineering toolkit lab I started off by entering into my Kali Linux environment and accessing the "setoolkit" menu via the command below. And before we even got the chance to explore the tool, as per the ethical requirements of a pentester, we had to read and agree to some terms and conditions with regard to how I would use the tool.
```bash
setoolkit
```
![img.png](Resources/Web_Cloning/img.png)

And after we have managed to access the toolkit we now have to access the website cloning tool. On the first screen after accepting the conditions we then choose the first option from the menu which is "Social-Engineering attacks", followed by the second option in the proceeding menu which is "Website attack vectors".
The webattack menu offers a number of different methods for exploiting websites in order to acquire sensitive information as shown below.

![img_1.png](Resources/Web_Cloning/img_1.png)

We ourselves however, will choose to focus on the credentials harvester for now which is option number 3 in the menu.
And the way with which we will harvest those credentials will be using a cloning tool which we will use to clone a website that we know is frequently accessed by the user and use that cloned platform to harvest the user's credentials before redirecting them to the actual site.

![2.jpg](Resources/Web_Cloning/2.jpg)

So the first thing that we need to already have before performing this attack is the target system for Posting the attack which an attacker would already have from their previous information gathering exercises using tools like nmap. And secondly we would require the ip-address of the website we desire to clone which is simply achievable using the reverse dns-lookup command in the terminal. And in our case we will be using the website "http://dvwa.vm"
![img_2.png](Resources/Web_Cloning/img_2.png)

After that we proceeded to create a very simple exploit that we would use for the purposes of this exercise which is show below. The exploit is a simple html file which can be recreated in a text editor.

![img_3.png](Resources/Web_Cloning/img_3.png)

Once we begin our actual exploit the snippet below is the cloned website that the target will be directed to initially. As you can see from the url that it is simply the ip-address of the local machine which is a detail that untrained users would simply overlook. So this page is where users would then enter their login credentials with the intent of accessing their desired website.  The tool however would then harvest these credentials forthe attacker.

![img_4.png](Resources/Web_Cloning/img_4.png)

And once the user has posted their credentials on the fake website they would instantly be redirected to the actual website in order to avoid any suspicion from the side of the user resulting in them changing said credentials.

![7.jpg](Resources/Web_Cloning/7.jpg)

And once we go back to Social-Engineering toolkit we will be able to view the information that the tool would have collected from the atack such as the username, password and user token. And as simply as that we would have acquired the password of the user and if the user has the habit of reusing the same password for multiple accounts this could be used to hack into all of them. Additionally it  could  be used as part of a dictonary password crackin attempt but either way these credentials would be quite valuable. 

![8.jpg](Resources/Web_Cloning/8.jpg)

And this last snippet shows how you can write and later access the recorded data from the exploit for further analysis.

![9.jpg](Resources/Web_Cloning/9.jpg)