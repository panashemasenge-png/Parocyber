
# 🛡️ Cybersecurity Practical Labs Portfolio

This repository documents hands-on cybersecurity labs conducted to understand **real-world attack techniques**, their execution, and the **security implications** of poor configurations and human vulnerabilities.

The labs focus on:

* Network and service enumeration
* Misconfiguration exploitation
* Social engineering attack vectors
* Practical use of offensive security tools
* Ethical considerations in penetration testing

---

## Lab 1: SMB Vulnerability Scanning using Enum4Linux

### Objective

To enumerate SMB services and identify misconfigurations that could be exploited by attackers.

### Tools Used

* Enum4Linux
* Nmap
* smbclient
* Kali Linux

### Summary of Activities

* Performed network discovery using Nmap
* Enumerated SMB users, shares, and password policies
* Identified publicly accessible and hidden shares
* Exploited anonymous SMB login
* Demonstrated the ability to upload files to writable shares

### Key Findings

* Weak SMB password policies
* Anonymous access enabled
* Writable public shares
* Potential for malware planting and lateral movement

### Lessons Learned

* Enumeration is a critical first step in cyber attacks
* Weak configurations expose organizations to severe risk
* SMB services must be tightly controlled and audited

---

## Lab 2: Website Cloning using Social Engineering Toolkit (SET)

### Objective

To understand how website cloning is used in **phishing and credential harvesting attacks**, and how attackers exploit user trust rather than technical vulnerabilities.

---

### Tools Used

* Social Engineering Toolkit (SET)
* Kali Linux
* HTML (basic exploit creation)
* DNS utilities (reverse lookup)

---

### Ethical Considerations

Before using SET, I reviewed and accepted the **ethical use agreement**, emphasizing that such tools must only be used for **authorized testing, education, or defensive security research**.

```bash
setoolkit
```

---

### Lab Walkthrough

#### 1️⃣ Accessing Social Engineering Toolkit

After launching SET in Kali Linux, I navigated through the menu structure:

* **Option 1:** Social-Engineering Attacks
* **Option 2:** Website Attack Vectors

This menu provides several attack methods targeting user behavior rather than systems.

---

#### 2️⃣ Selecting Credential Harvester Attack

From the Website Attack Vectors menu, I selected:

* **Option 3:** Credential Harvester Attack Method
* **Website Cloner**

This method clones a legitimate website and captures user credentials entered on the fake page.

---

#### 3️⃣ Target and Website Identification

For the attack to work, two components were required:

1. **Attack host IP address** – obtained from prior reconnaissance
2. **Target website IP address** – retrieved using reverse DNS lookup

In this lab, the target site was:

```
http://dvwa.vm
```

---

#### 4️⃣ Creating a Simple Exploit

A basic HTML-based exploit was created using a text editor. This exploit served as the credential collection mechanism once users submitted login details.

---

#### 5️⃣ Executing the Website Cloning Attack

Once the attack was launched:

* The cloned website was hosted on the attacker’s local IP address
* Users were redirected to the fake login page
* The URL showed an IP address instead of a domain name — a detail often overlooked by untrained users

Users unknowingly entered credentials believing the page to be legitimate.

---

#### 6️⃣ Credential Harvesting and Redirection

After credentials were submitted:

* SET harvested the username, password, and session token
* The victim was automatically redirected to the **real website**
* This redirection reduced suspicion and delayed detection

---

#### 7️⃣ Viewing and Storing Captured Credentials

Captured credentials were displayed directly within SET and could also be written to files for later analysis.

This demonstrated how:

* A single phishing attempt can compromise accounts
* Password reuse amplifies attack impact
* Harvested credentials can be reused in further attacks

---

### Security Implications

This lab highlights that:

* Humans are often the weakest link in security
* Phishing attacks require minimal technical complexity
* URL awareness and user education are critical
* Credential reuse significantly increases risk exposure

---

###  Lessons Learned

* Social engineering bypasses many technical defenses
* Website cloning is highly effective against unaware users
* Users must verify URLs and HTTPS certificates
* Security awareness training is essential for organizations

---

## Overall Key Takeaways

Across both labs, the following insights were reinforced:

* Technical vulnerabilities and human weaknesses are equally dangerous
* Enumeration and reconnaissance enable most cyber attacks
* Misconfigurations significantly reduce attack complexity
* Defense requires both **secure systems** and **educated users**

---

##  Repository Structure

```
cybersecurity-labs/
├── README.md
├── smb_enum4linux/
│   └── Resources/
├── Web_Cloning/
│   └── Resources/
```


