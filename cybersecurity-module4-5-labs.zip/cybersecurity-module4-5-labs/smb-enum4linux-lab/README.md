# SMB Vulnerability Scanning using Enum4Linux

## Objective
To enumerate SMB services and identify misconfigurations.

As started to dive into this lab I started of by exploring the vast number of options that are offered by the enum4linux tool.

```bash
enum4linux -help
```

![a.jpg](Resources/smb_enum4linux/a.jpg)

After going through all the options available for use I then proceeded to run a nmap scan of the target network to identify all the exploitable hosts on the network including a report for each host showing the port status of the various ports there. (Take note that all nmap functions require administrator priviledges)

```bash
sudo su 
nmap -sN 172.17.0.0/24
```
![b.jpg](Resources/smb_enum4linux/b.jpg)
![c.jpg](Resources/smb_enum4linux/c.jpg)

After running the network wide scan to identify all the hosts that would be available to an attacker we then proceed to choose one host which will be the target of our attacks. In my case i made use of the host 172.17.0.2. Ang now using the get Userlist (-U) option of enum4linux we then enumerate our specific target host and this enumeration also includes information about smb shares contained on that particular host including information like which of those shares are public, associated usernames and more. From my particular example I identified 4 shares with the tmp and opt shares being the only one accessible as those marked with a "$" sign indicate hidden shares.

```bash
enum4linux -U 172.17.0.2
```
![d.jpg](Resources/smb_enum4linux/d.jpg)
![e.jpg](Resources/smb_enum4linux/e.jpg)

On top of the share enumeration it also often wise to enumerate the password policy as it can help you during the penetration test to evaluate what methods are available to you to try and gain access to said resources. And looking at my example below you can note that this password policy is quite weak and missing key components like a password age which makes sure that the password changes constantly.

```bash
enum4linux -P 172.17.0.2
```

![f.jpg](Resources/smb_enum4linux/f.jpg)
![g.jpg](Resources/smb_enum4linux/g.jpg)

As the next step I then proceeded to login into the host using smbclient and taking advantage of the host's configuration that allows anonymous logins. This permits us to confirm all the shares that are contained in the host before we continue to choose a particular share that we want to work with, in this case that share is "tmp". Once the login is ssuccessful you will see the "smb: \>" prompt to indicate that you are now working within that share.

```bash
smbclient -L //172.17.0.2/tmp
```

![h.jpg](Resources/smb_enum4linux/h.jpg)
![i.jpg](Resources/smb_enum4linux/i.jpg)

Within the chosen share that we chose and using the smbclient we can now view all the directories in the share using the "dir" command which returns all the information regarding to the contents of that particular share. 

![j.jpg](Resources/smb_enum4linux/j.jpg)

In the following snippet you can see how i explored options within the smbclient that permit users to write or paste into the shares that they have successfully logged into. In my case i made use of text editor to create a sample file "called virus.exe". Then using the "put" command of the smbclient copied that file into the share whilst simultaneously renaming it so as to not arouse suspicion. 

```bash
put virus.exe group_work.txt
```

![k.jpg](Resources/smb_enum4linux/k.jpg)

And below you can confirm that once you recheck the directories in the share there is now inclusion of the "group_work.txt" file that a potential attacker would have planted there for an unsuspecting user accidentally run.

![l.jpg](Resources/smb_enum4linux/l.jpg)

Going thhrough this lab really strengthened my understanding of how seemingly innocent misconfiguurations can be exploited by threat actors to compromise systems very easily and cost companies a lot of time and money trying to resolve and also figure out how this happened to begin with.