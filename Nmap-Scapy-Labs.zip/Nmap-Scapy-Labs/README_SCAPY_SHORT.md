Short Scapy quick-reference:
- Craft ICMP: packet = IP(dst='x')/ICMP()
- Send: send(packet)
- Sniff: sniff(count=10)
- Filter: sniff(filter='tcp port 80', count=20)
