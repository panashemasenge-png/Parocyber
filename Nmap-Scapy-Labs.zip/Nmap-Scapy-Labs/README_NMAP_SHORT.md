Short Nmap quick-reference:
- Host discovery: nmap -sn <network>
- TCP scan: nmap -sS <target>
- Service detect: nmap -sV <target>
- OS detect: nmap -O <target>
- NSE vuln: nmap --script=vuln <target>
