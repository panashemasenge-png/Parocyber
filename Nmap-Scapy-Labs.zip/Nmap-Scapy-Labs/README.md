# Nmap & Scapy Practical Labs

**Author:** [Your Name]
**Course:** Cybersecurity Fundamentals
**Purpose:** Reproduction and documentation of in-class Nmap and Scapy labs. This repository contains commands, scripts, and explanations used to perform host discovery, port/service enumeration, OS fingerprinting, NSE scanning with Nmap, and packet crafting/sniffing with Scapy.

## Objectives
- Re-run and document Nmap scans: host discovery, port scanning, service detection, OS fingerprinting, NSE.
- Recreate Scapy exercises: packet crafting, sending, sniffing, and protocol analysis.
- Provide clear README, code snippets, and structured documentation for each lab.
- Provide placeholders for screenshots which will be supplied separately.

## Repository structure
```
/Nmap-Scapy-Labs
├── nmap/
│   ├── host_discovery.md
│   ├── port_scan.md
│   ├── service_detection.md
│   ├── os_fingerprinting.md
│   ├── nse_scans.md
│   └── scripts/
│       └── nmap_examples.sh
├── scapy/
│   ├── packet_crafting.md
│   ├── sending_packets.md
│   ├── sniffing.md
│   ├── filtering.md
│   └── scripts/
│       ├── craft_icmp.py
│       ├── sniff_http.py
│       └── send_tcp_syn.py
├── docs/
│   └── linkedin_post.md
├── .gitignore
├── LICENSE
└── requirements.txt
```

## How to use
1. Clone the repo to your local machine.
2. Review `requirements.txt` and install dependencies (`pip install -r requirements.txt`) if running Scapy scripts.
3. Review and run Nmap commands inside the `nmap/` folder. Add screenshots in the `nmap/screenshots/` and `scapy/screenshots/` folders.
4. Replace placeholder text and screenshot placeholders with your lab evidence.
