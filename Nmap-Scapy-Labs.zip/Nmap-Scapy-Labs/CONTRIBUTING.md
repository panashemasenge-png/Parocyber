# Contributing

Thank you for your interest. This repository is a personal lab reproduction. To contribute:
- Fork the repo
- Open a PR with changes to docs or scripts
- Do not add screenshots without author's consent (privacy)
