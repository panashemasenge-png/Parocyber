# Nmap Scripting Engine (NSE)

**Objective:** Run automated scripts to detect known vulnerabilities and misconfigurations.

**Command:**
```bash
nmap --script=vuln 192.168.1.10
```

**What I assessed & how I ran it:**
I ran a selection of NSE scripts (vuln, safe, discovery categories) to detect common issues such as SMB misconfigurations, HTTP vulnerabilities, and weak SSL/TLS settings. I reviewed outputs and validated findings with additional tools when necessary.

![img_3.png](img_3.png)

**What the scan did:**
This command instructs Nmap to:

1. Check if SMB is running on port 445
2. Run the smb-enum-shares script
3. Attempt to list:


Shared folders
Access permissions  
Guest/anonymous access availability     
Hidden administrative shares (C$, ADMIN$, etc.)


4. Report misconfigurations or open shares