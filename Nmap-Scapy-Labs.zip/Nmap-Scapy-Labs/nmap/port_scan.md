# Basic Port Scan

**Objective:** Discover open TCP ports on a target host.

**Command:**
```bash
nmap 10.6.6.23
```

**What I assessed & how I ran it:**
I ran a default TCP SYN scan to enumerate the most common open ports. After confirming which ports were open I selected specific ports for further service/version checks and NSE scripts.


