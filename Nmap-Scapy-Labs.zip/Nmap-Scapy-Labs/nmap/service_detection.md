# Service Version Detection

**Objective:** Identify service versions and banners for exposed services.

**Command:**
```bash
nmap -p21 -sV -A 10.6.6.23
```

**What I assessed & how I ran it:**
I targeted discovered open ports to aggressively find running services and their versions. This allowed me to identify outdated software and map potential CVEs to services.


> ![img_1.png](img_1.png)


As well as the more refined scan below.
```bash
nmap -p21 -sV -A -T24 10.6.6.23
```

> ![img_2.png](img_2.png)

The same scan was also repeated across a number of the other open ports exploring what type of invaluable data might be hidden within them.