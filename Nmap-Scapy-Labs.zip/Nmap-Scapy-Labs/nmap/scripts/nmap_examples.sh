#!/bin/bash
# Example Nmap commands used in the labs
nmap -sn 192.168.1.0/24
nmap -sS 192.168.1.10
nmap -sV 192.168.1.10
nmap -O 192.168.1.10
nmap --script=vuln 192.168.1.10
