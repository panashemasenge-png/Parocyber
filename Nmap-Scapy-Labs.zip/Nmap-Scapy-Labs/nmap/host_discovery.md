# Host Discovery

**Objective:** Identify live hosts on a network with minimal intrusion.

**Command:**
```bash
nmap -sn 10.6.6.0/24
```

**What I assessed & how I ran it:**
I executed a ping sweep to determine which addresses respond to ICMP or ARP probes. On a local lab network I observed which hosts were up and recorded their IP and MAC where available. Results helped target further scans and avoid scanning offline hosts.

> ![alt text](image.png)
