# OS Fingerprinting

**Objective:** Determine the operating system of a target host.

**Command:**
```bash
nmap -O 10.6.6.23
```

**What I assessed & how I ran it:**
Using TCP/IP stack fingerprinting, Nmap analyzes responses to various probes to infer OS and network device types. I documented the confidence level and alternative matches that Nmap returned.

> ![img.png](img.png)
