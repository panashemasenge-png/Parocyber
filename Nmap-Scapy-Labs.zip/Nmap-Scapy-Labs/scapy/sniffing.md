# Sniffing Traffic with Scapy

**Objective:** Capture live traffic and analyze packet flows.

**What I assessed & how I ran it:**
I captured live traffic on the lab interface, used filters to isolate traffic of interest, and inspected payloads and flags to better understand communications between hosts.


**Example 1:**

I initially started with an unfiltered continuous sniff that helped me to analyze some of the most common traffic on the network as i simultaneosly ran multiple operations including pings in an adjacent window.
```bash
sniff()
```

![img.png](img.png)


Following the termination of the sniff i then proceeded to save the sniffed data in an object named "sample" and applied the ".summary()" method to the object to provide me with a more focused view ofthe collected data.    
**Example 2:**
```bash
sample=_
sample.summary()
```
![img_1.png](img_1.png)

**Example 3:**

I then proceeded to conduct more targeted searches by focusing on more specific interfaces of my VM and eventually filtering the types of traffic.       

![img_2.png](img_2.png)

        
![img_3.png](img_3.png)

I finished of by looking at how to further investigate individual packets to view and extract the different elements that make-up each packet.
```bash
sniff[n]
```
![img_4.png](img_4.png)